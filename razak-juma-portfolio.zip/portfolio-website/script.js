// Add interactive features here if needed
console.log("Razak Juma's website loaded");